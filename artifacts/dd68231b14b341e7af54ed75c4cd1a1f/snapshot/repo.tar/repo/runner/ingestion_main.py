from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

if TYPE_CHECKING:
    from core.storage.artifacts import ArtifactLayout
    from shared.ingestion_types import RunRecord, RunStatus


def ensure_repo_root_on_path() -> Path:
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.append(str(repo_root))
    return repo_root


@dataclass
class RunRepository:
    layout: "ArtifactLayout"

    def create_run(self, repo_url: str, start_prompt: str | None) -> "RunRecord":
        from shared.ingestion_types import RunRecord, RunStatus

        run_id = uuid4().hex
        now = datetime.now(tz=UTC)
        run = RunRecord(
            run_id=run_id,
            repo_url=repo_url,
            status=RunStatus.PENDING,
            commit_sha=None,
            start_prompt=start_prompt,
            created_at=now,
            updated_at=now,
        )
        self.layout.ensure_run_layout(run_id)
        self._write_run(run)
        return run

    def update_status(self, run: "RunRecord", status: "RunStatus") -> "RunRecord":
        now = datetime.now(tz=UTC)
        updated = run.model_copy(update={"status": status, "updated_at": now})
        self._write_run(updated)
        return updated

    def update_commit(self, run: "RunRecord", commit_sha: str) -> "RunRecord":
        now = datetime.now(tz=UTC)
        updated = run.model_copy(update={"commit_sha": commit_sha, "updated_at": now})
        self._write_run(updated)
        return updated

    def get_run(self, run_id: str) -> "RunRecord":
        from shared.ingestion_types import RunRecord

        data = self.layout.run_meta_path(run_id).read_text(encoding="utf-8")
        return RunRecord.model_validate_json(data)

    def _write_run(self, run: "RunRecord") -> None:
        path = self.layout.run_meta_path(run.run_id)
        path.write_text(run.model_dump_json(indent=2), encoding="utf-8")


def run_once(repo_url: str, start_prompt: str | None, artifacts_root: Path) -> str:
    ensure_repo_root_on_path()
    from core.storage.artifacts import ArtifactLayout
    from runner.snapshot import Snapshotter
    from shared.ingestion_types import RunStatus

    layout = ArtifactLayout(artifacts_root)
    repo = RunRepository(layout)
    run = repo.create_run(repo_url, start_prompt)
    run = repo.update_status(run, RunStatus.RUNNING)
    snapshotter = Snapshotter(work_dir=layout.run_dir(run.run_id) / "snapshot")
    snapshot_dir = layout.run_dir(run.run_id) / "snapshot" / "repo"
    snapshot_result = snapshotter.run(repo_url, snapshot_dir, create_archive=True)
    repo_meta_path = layout.run_dir(run.run_id) / "snapshot" / "repo_meta.json"
    repo_meta_path.write_text(
        snapshot_result.meta.model_dump_json(indent=2), encoding="utf-8"
    )
    run = repo.update_commit(run, snapshot_result.meta.commit_sha)
    run = repo.update_status(run, RunStatus.DONE)
    return run.run_id


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run ingestion once")
    parser.add_argument("--repo_url", required=True)
    parser.add_argument("--start_prompt")
    parser.add_argument("--artifacts_root")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    repo_root = ensure_repo_root_on_path()
    from core.storage.artifacts import default_artifacts_root

    artifacts_root = (
        Path(args.artifacts_root)
        if args.artifacts_root
        else default_artifacts_root(repo_root)
    )
    run_id = run_once(args.repo_url, args.start_prompt, artifacts_root)
    print(run_id)


if __name__ == "__main__":
    main()

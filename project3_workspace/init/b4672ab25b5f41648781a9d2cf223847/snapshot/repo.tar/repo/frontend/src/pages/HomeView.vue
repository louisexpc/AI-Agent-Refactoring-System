<script setup>
import AppNavigation from '@/components/AppNavigation.vue';
import AppHero from "@/components/AppHero.vue"
</script>

<template>
  <AppNavigation />
  <AppHero />
</template>

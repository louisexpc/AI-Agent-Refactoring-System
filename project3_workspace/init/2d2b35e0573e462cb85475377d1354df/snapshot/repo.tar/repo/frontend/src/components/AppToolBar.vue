<template>
  <div class="bg-black text-white text-center pa-3 px-12 ga-10">
    <h6 class="w-100 text-center">Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!
      <a href="#" class="ml-1" style="border-bottom: 1px solid #FFF;">ShopNow</a>
    </h6>
  </div>
</template>

<style scoped>
a {
  color: #FFF;
}
</style>

npm install swagger-ui-express swagger-jsdoc
http://localhost:3000/docs/

